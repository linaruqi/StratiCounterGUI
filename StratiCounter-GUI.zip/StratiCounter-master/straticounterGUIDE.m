function varargout = straticounterGUIDE(varargin)
% STRATICOUNTERGUIDE MATLAB code for straticounterGUIDE.fig
%      STRATICOUNTERGUIDE, by itself, creates a new STRATICOUNTERGUIDE or raises the existing
%      singleton*.
%
%      H = STRATICOUNTERGUIDE returns the handle to a new STRATICOUNTERGUIDE or the handle to
%      the existing singleton*.
%
%      STRATICOUNTERGUIDE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STRATICOUNTERGUIDE.M with the given input arguments.
%
%      STRATICOUNTERGUIDE('Property','Value',...) creates a new STRATICOUNTERGUIDE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before straticounterGUIDE_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to straticounterGUIDE_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help straticounterGUIDE

% Last Modified by GUIDE v2.5 22-Dec-2023 20:45:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @straticounterGUIDE_OpeningFcn, ...
                   'gui_OutputFcn',  @straticounterGUIDE_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before straticounterGUIDE is made visible.
function straticounterGUIDE_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to straticounterGUIDE (see VARARGIN)

% Choose default command line output for straticounterGUIDE
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes straticounterGUIDE wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = straticounterGUIDE_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Example of settings for the data record from the NEEM-2011-S1 ice core.
% Data reference: Sun et al (2014), Ash from Changbaishan Millennium 
% eruption recorded in Greenland ice: Implications for determining the 
% eruption's timing and impact, GRL 41, 2, pp. 694?701, 10.1002/2013GL058642. 

% Mai Winstrup, 2015

%% Data files:
[txtfile,txtpath] = uigetfile('*.txt');
% manualcounts_data = load(txtfile); % 根据文件格 式和类型选择合适的读取函数
% manualcounts = manualcounts_data; % 将读取的数据赋值给 manualcounts 变量
save('wenjian.mat',"txtfile");
set(handles.edit13,'String',txtfile);;
% mignzi=get(handles.edit13,'String');
Model.icecore=get(handles.edit1,'String');
% Model.icecore = 'NEEM-2011-S1_example';%变量自定义
% In the datafile, two data series exist for this core: Cl and nssS. 
% Here, we choose only to use the Cl record.
species=get(handles.edit2,'String');
Model.species = {species};%变量自定义
Model.nSpecies = length(Model.species);

% Weighting of various species:
Model.wSpecies = ones(Model.nSpecies,1);

% Path to data file:
Model.path2data =get(handles.edit3,'String');
% Model.path2data = './Data/data_example.mat';%变量自定义

%% Depth interval [m]:
Model.dstart =str2num(get(handles.edit4,'String'));
Model.dend=str2num(get(handles.edit5,'String'));
% Model.dstart = 202;%变量自定义
% Model.dend = 209; %变量自定义

%% Marker horizons to be used as tiepoints?
% No tiepoints:
zhi=get(handles.radiobutton1,'value');
if zhi==0
    Model.tiepoints=[];
    set(handles.edit7,'Enable','off');
elseif zhi==1
    Model.tiepoints(:,1)=str2num(get(handles.edit7,'String'));
    Model.tiepoints(:,2)=str2num(get(handles.edit8,'String'));
end
% 
% Model.tiepoints=str2num(get(handles.edit6,'String'));
% Model.tiepoints(:,1)=str2num(get(handles.edit7,'String'));
% Model.tiepoints(:,2)=str2num(get(handles.edit8,'String'));
% Model.tiepoints = [];%变量自定义（下方with tiepoints这个是常用的情况，3行内容）
% With tiepoints:
%Model.tiepoints(:,1) = [203 208]; % Depth [m] 这个是第一截的深度
%Model.tiepoints(:,2) = [958 930]; % Corresponding age 最后一截的深度
%Model.ageUnitTiepoints = 'AD'; % Age unit of tiepoints 可选四个选项AD, BP, b2k, layers
% Options: AD, BP, b2k, layers

%% Data treatment:
% Resolution of data series to be used:
Model.dx=str2num(get(handles.edit9,'String'));
% Model.dx_offset=str2num(get(handles.edit10,'String'));

suoyin=(get(handles.popupmenu1,'value'));
shuzhi=(get(handles.popupmenu1,'String'));
Model.dx_offset=shuzhi{suoyin,1};

% Model.dx = 10^-2; % [m/datapoint]%变量自定义
% Model.dx_offset = 0;%变量自定义
% If using e.g. midpoints of dx intervals, the value of dx_offset should
% be set as 0.5 (to avoid unnecessary interpolation). 

% Preprocessing of each data series:
for j = 1:Model.nSpecies
    Model.preprocsteps{j,1} = {'zscore',1};
    Model.preprocsteps{j,2} = []; 
end
% 1st row: Initial preprocessing
% 2nd row: Batch preprocessing 

% Possible preprocessing steps:
% Non-distance dependent transformations:
% - No processing ([])
% - Interpolation over nans ('interpNaNs')
% - Subtract mean ('minusmean')
% - Log-transformation ('log')
% - Box-Cox transformation ('boxcox',[],[lambda, (alpha)])
% Distance-dependent transformations:
% - Normalization using standard deviation ('zscore',Lwindow)
% - Normalization using min-max ('minmax', Lwindow)
% - Normalization using quantiles ('quantile', Lwindow)
% - Using CDF-transform ('cdftransform',Lwindow)
% - Subtract baseline ('minusbaseline',Lwindow,(quantile))
% - Subtract smooth curve calculated using running average ('minussmooth', Lwindow)
% Window lengths are given in m (1st row) or in terms of lambda (2nd row). 

%% Length of each data batch (in approximate number of layers):
Model.nLayerBatch = 50; 
% If tiepoints are given, the length of each data batch corresponds to the
% interval between these. 

%% Provide path to manual layer counts to be used for initialization:
% Model.nameManualCounts = 'counts_example.txt';%变量自定义
Model.nameManualCounts =get(handles.edit11,'String');
Model.ageUnitManual = 'AD';
% Format of file with manual layer counts:
% counts(:,1): Depth
% counts(:,2): Age
% counts(:,3): Uncertainty of layer (0: certain, 1: uncertain)
% counts(:,4): Accumulated uncertainty from start of interval

%% The annual layer model: 
% Depth interval used for determining layer shapes based on preliminary 
% manual layer counts: 
Model.manualtemplates = [Model.dstart Model.dend];

%% Initial model parameters and variation allowed:
% The initial set of layer parameters will be based on manual layer counts.
% Depth interval used to estimate these:
Model.initialpar = [Model.dstart, Model.dstart+0.5*(Model.dend-Model.dstart)];
% Using the first half of data.

%% Iterations and convergence:
% Number of iterations per batch:
Model.nIter = str2num(get(handles.edit14,'String'));;

% Parameters allowed to be updated at each iteration.
% The ordering is: 
% 1: my, 2: sigma (mode and variace of layer thickness distribution)
% 3: par, 4: cov, 5: nvar (layer shape mean parameters, inter-annual 
% covariance and white noise component)
Model.update = {'ML', 'ML', 'ML', 'ML', 'ML'}; 
% Options:
% 'none': No updates (i.e. maintained as layerpar0)
% 'ML': Maximum-Likelihood updates

% Option for iteration over templates: 
% After running StratiCounter once, this option allows a new set of 
% templates to be produced and used for re-running StratiCounter. The final
% result will be that based on the new set of templates. 
% Number of template iterations:
Model.nTemplate = 1; 
% If 1: Layer templates are based on manual counts.

%% Output of algorithm:
% Length of interval(s) for determining average layer thicknesses:
% Model.Out.dxLambda = [1 5]; % [m]%变量自定义
Model.Out.dxLambda =str2num(get(handles.edit12,'String'));
% If empty, lambda values are not determined.

% Specific depth sections for mean layer thickness calculations:
Model.Out.dMarker = [];
% Several sections can be included as follows:
% Model.Out.dMarker{1} = [101, 152.5, 204];
% Model.Out.dMarker{2} = [121, 142, 201];
% Distributions are also calculated for the section from the beginning of 
% the data series to the first marker horizon, and from the last
% marker horizon within data series to end of the data series. 

% Which timescale terminology to be used for output? 
% Model.Out.ageUnit = 'AD';
suoyin1=(get(handles.popupmenu2,'value'));
shuzhi1=(get(handles.popupmenu2,'String'));
Model.Out.ageUnit=shuzhi1{suoyin1,1};

% Options: AD, BP, b2k, layers
straticounter('sett_example')



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zhi=get(handles.radiobutton1,'value');
if zhi==0
    Model.tiepoints=[];
    set(handles.edit7,'Enable','off');
    set(handles.edit8,'Enable','off');
elseif zhi==1
     set(handles.edit7,'Enable','on');
    set(handles.edit8,'Enable','on');
    Model.tiepoints(:,1)=str2num(get(handles.edit7,'String'));
    Model.tiepoints(:,2)=str2num(get(handles.edit8,'String'));
end

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
