files.core{1}='counts_example'; 
files.datafile{1}='data_all.mat'; 
files.matchfile{1}='./Output/NEEM-2011-S1_example/Matchfiles/layers_manual.mat'; 
 
files.core{2}='NEEM-2011-S1_example'; 
files.datafile{2}='data_auto.mat'; 
files.matchfile{2}='./Output/NEEM-2011-S1_example/Matchfiles/layers_auto.mat'; 
 
